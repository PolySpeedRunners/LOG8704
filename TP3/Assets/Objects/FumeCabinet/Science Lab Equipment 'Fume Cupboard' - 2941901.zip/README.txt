Science Lab Equipment 'Fume Cupboard' by MajorMuppet on Thingiverse: https://www.thingiverse.com/thing:2941901

Summary:
Looking to fill out a Science Lab Diorama? This is a model of actual equipment used in labs. Its a fume extraction device normal height is floor to ceiling. My first 3D made object ever.  